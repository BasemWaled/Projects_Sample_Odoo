
{
    'name': 'Pay K_Matrix',
    'version': '15.0',
    'category': 'manging',
    'summary': 'Pay Mobile',
    'description': """ testing pay """,
    'author': 'K_Matrix',
    'depends': ['account'],
    'data': [],
    'demo': [],
    'sequence': '-98',
    'application': True,
    'installable': True,
    'auto_install': False,
    'assets': {
    },

}
